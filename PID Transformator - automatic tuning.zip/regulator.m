%% Matlab a simulink do VA1

% P�vodn� rovnice 3y''' + y'' + 3y' + 2y = u nebyla stabiln� podle Hurwitzova krit�ria

% Proto jsem si rovnici upravil na 3y''' + 10y'' + 3y' + 2y = u, a tu jsem pou�il ve v�po�tech. 
 
% V m�m simulinku vykresluji 3 grafy: Pro p�ehlednost vykresluji hodnoty vypo�ten� pomoc� Ziegler-Nicholsovi metody pro oba ko�eny w
%                                     D�le vykresluji i graf regul�toru, kter� jsem nastavil ru�n� na z�klad� z�skan�ch hodnot z Ziegler-Nicholsovi metody 

% V p��pad�, �e je soustava nestabiln� podle Hurwitzova krit�ria, tak se skript v�bec nespust� a je po��d�no o jej� zm�n�n�

% Sta�� spustit tento MATLAB script (simulink i matlab extrahovat do stejn� slo�ky pros�m)


%%  ZAD�N� PARAMETR� P�ENOSOV� FUNKCE

x3 = 2;
x2 = 10;
x1 = 3;
x0 = 2;
u = 1;

s = 1;
G(s) = u/(x3*(s^3)+x2*(s^2)+x1*s+x0);

%% Zji�t�n� stability syst�mu a v�po�et r0
syms r;
a3=x3;
a2=x2;
a1=x1;
a0 = x0 + u*r;

H2=[a2 a0; a3 a1];
D1 = a2*a1 ;
D2 = a3*a0;
r0k=solve(D1-D2, r);


    if (r0k < 0)
        fprintf("Determinant je men�� ne� 0. Syst�m nen� stabiln�. \n \n \n");
        return
    else
        fprintf("Syst�m je stabiln�. \n \n \n");
    end
    
r0 = double(r0k*0.6);

%% V�po�et ko�en� w
syms w;
equation = -x1*w^3 - x2*w^2 + x3*w + x0+r0k == 0;
solution = solve(equation, w);

wt1 = solution(1);
wt2 = solution(2);

%% V�po�et Tk, Ti, Td pro oba ko�eny w

Tk1 = 2*pi/wt1;
Ti1 = 0.5 * Tk1;
ri1 = double(-r0/Ti1);
Td1 = Tk1/8;
rd1 = double(-r0*Td1);

Tk2 = 2*pi/wt2;
Ti2 = 0.5 * Tk2;
ri2 = double(-r0/Ti2);
Td2 = Tk2/8;
rd2 = double(-r0*Td2);

%% Spu�t�n� simulinku
sim('pidtar');
open_system('pidtar/Scope');
